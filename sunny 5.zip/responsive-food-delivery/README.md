# TastyBite - Responsive Food Delivery Website

A Web Technology mini project built with:
- HTML5
- CSS3
- JavaScript
- Responsive design
- LocalStorage cart persistence

## Features
- Responsive navigation
- Food category filters
- Add to cart
- Increase/decrease quantity
- Remove cart items
- Automatic total calculation
- Checkout form
- Offer coupon interaction
- Mobile responsive design
- Cart data saved in browser LocalStorage

## How to Run
1. Extract the ZIP file.
2. Open the folder in VS Code.
3. Open `index.html` in a browser.
4. For best experience, install the VS Code **Live Server** extension and click **Go Live**.
