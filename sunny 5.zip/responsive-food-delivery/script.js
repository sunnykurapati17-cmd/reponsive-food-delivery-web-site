const foods=[
{id:1,name:"Margherita Pizza",cat:"pizza",emoji:"🍕",desc:"Cheesy classic pizza with fresh herbs",price:249},
{id:2,name:"Veggie Pizza",cat:"pizza",emoji:"🍕",desc:"Loaded with colorful fresh vegetables",price:299},
{id:3,name:"Cheese Burger",cat:"burger",emoji:"🍔",desc:"Juicy patty with cheese and fresh veggies",price:189},
{id:4,name:"Crispy Chicken Burger",cat:"burger",emoji:"🍔",desc:"Crispy chicken with special sauce",price:229},
{id:5,name:"Butter Paneer",cat:"indian",emoji:"🍛",desc:"Rich creamy paneer curry",price:219},
{id:6,name:"Veg Biryani",cat:"indian",emoji:"🍚",desc:"Aromatic basmati rice with spices",price:199},
{id:7,name:"Chocolate Cake",cat:"dessert",emoji:"🍰",desc:"Soft chocolate cake with creamy layers",price:149},
{id:8,name:"Ice Cream",cat:"dessert",emoji:"🍨",desc:"Creamy and refreshing dessert",price:99}
];
let cart=JSON.parse(localStorage.getItem("tastybiteCart")||"[]"), active="all";
const grid=document.getElementById("foodGrid"),cartItems=document.getElementById("cartItems"),count=document.getElementById("cartCount"),total=document.getElementById("total");
function renderFood(){let list=active==="all"?foods:foods.filter(f=>f.cat===active);grid.innerHTML=list.map(f=>`<div class="food-card"><div class="food-img">${f.emoji}</div><div class="food-info"><h3>${f.name}</h3><p>${f.desc}</p><div class="card-bottom"><span class="price">₹${f.price}</span><button class="add-btn" onclick="addToCart(${f.id})">+ Add</button></div></div></div>`).join("")}
function save(){localStorage.setItem("tastybiteCart",JSON.stringify(cart));renderCart()}
function addToCart(id){let item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({...foods.find(f=>f.id===id),qty:1});save();toast("Added to cart!")}
function changeQty(id,n){let item=cart.find(x=>x.id===id);item.qty+=n;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);save()}
function removeItem(id){cart=cart.filter(x=>x.id!==id);save()}
function renderCart(){count.textContent=cart.reduce((s,x)=>s+x.qty,0);if(!cart.length){cartItems.innerHTML='<p class="empty">Your cart is empty 🛒</p>';total.textContent="₹0";return}cartItems.innerHTML=cart.map(x=>`<div class="cart-item"><div class="cart-emoji">${x.emoji}</div><div class="cart-item-main"><b>${x.name}</b><p>₹${x.price*x.qty}</p><div class="qty"><button onclick="changeQty(${x.id},-1)">−</button><span>${x.qty}</span><button onclick="changeQty(${x.id},1)">+</button></div></div><button class="remove" onclick="removeItem(${x.id})">Remove</button></div>`).join("");total.textContent="₹"+cart.reduce((s,x)=>s+x.price*x.qty,0)}
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{active=b.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderFood()});
const panel=document.getElementById("cartPanel"),overlay=document.getElementById("overlay");
function openCart(){panel.classList.add("open");overlay.classList.add("show")}function closeCart(){panel.classList.remove("open");overlay.classList.remove("show")}
document.getElementById("cartBtn").onclick=openCart;document.getElementById("closeCart").onclick=closeCart;overlay.onclick=closeCart;
document.getElementById("menuBtn").onclick=()=>document.getElementById("nav").classList.toggle("show");
document.getElementById("checkoutBtn").onclick=()=>{if(!cart.length)return toast("Please add food to your cart first");document.getElementById("checkoutModal").classList.add("show")};
document.getElementById("closeModal").onclick=()=>document.getElementById("checkoutModal").classList.remove("show");
document.getElementById("orderForm").onsubmit=e=>{e.preventDefault();let n=document.getElementById("customerName").value;cart=[];save();document.getElementById("checkoutModal").classList.remove("show");closeCart();e.target.reset();toast("Thank you, "+n+"! Your order has been placed 🎉")};
document.getElementById("offerBtn").onclick=()=>toast("Coupon WELCOME25 copied! 25% discount applied on your first eligible order.");
function toast(msg){let t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
renderFood();renderCart();
